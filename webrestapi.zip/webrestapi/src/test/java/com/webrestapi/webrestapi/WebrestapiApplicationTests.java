package com.webrestapi.webrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
